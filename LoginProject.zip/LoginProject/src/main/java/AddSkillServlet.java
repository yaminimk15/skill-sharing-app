import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/addskill")
public class AddSkillServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request,
                          HttpServletResponse response)
            throws ServletException, IOException {

        String skill = request.getParameter("skill");
        String category = request.getParameter("category");

        try {

            // 🔹 Get user_id from session
            HttpSession session = request.getSession();
            Integer userId = (Integer) session.getAttribute("user_id");

            // 🔸 Safety check (VERY IMPORTANT)
            if (userId == null) {
                response.getWriter().println("User not logged in");
                return;
            }

            // 🔹 Load MySQL driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // 🔹 Database connection
            Connection con = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/login_project",
                    "root",
                    ""
            );

            // 🔹 Insert skill with user_id
            PreparedStatement ps = con.prepareStatement(
                    "INSERT INTO skills(skill_name, category, user_id) VALUES (?, ?, ?)"
            );

            ps.setString(1, skill);
            ps.setString(2, category);
            ps.setInt(3, userId);

            ps.executeUpdate();

            // 🔹 Redirect after success
            response.sendRedirect("dashboard.jsp");

        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().println("Error: " + e.getMessage());
        }
    }
}