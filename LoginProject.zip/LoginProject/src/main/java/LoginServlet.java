import java.io.IOException;
import java.sql.*;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import org.mindrot.jbcrypt.BCrypt;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request,
                          HttpServletResponse response)
            throws ServletException, IOException {

        String username = request.getParameter("username");
        String password = request.getParameter("password");

        if (username == null || password == null ||
            username.isEmpty() || password.isEmpty()) {

            response.getWriter().println("All fields are required");
            return;
        }

        try {

            Class.forName("com.mysql.cj.jdbc.Driver");

            Connection con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/login_project",
                "root",
                ""
            );

            PreparedStatement ps = con.prepareStatement(
                "SELECT id, username, password FROM users WHERE username=?"
            );

            ps.setString(1, username);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {

                String storedHash = rs.getString("password");

                if (BCrypt.checkpw(password, storedHash)) {

                    // 🔐 Secure session
                    HttpSession oldSession = request.getSession(false);
                    if (oldSession != null) oldSession.invalidate();

                    HttpSession session = request.getSession(true);
                    session.setAttribute("user_id", rs.getInt("id"));
                    session.setAttribute("username", rs.getString("username"));

                    response.sendRedirect("dashboard");

                } else {
                    response.getWriter().println("Invalid password");
                }

            } else {
                response.getWriter().println("User not found");
            }

        } catch(Exception e){
            e.printStackTrace();
            response.getWriter().println("Error: " + e.getMessage());
        }
    }
}