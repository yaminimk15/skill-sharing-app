import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/ratesessions")
public class RateSessionsServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request,
                         HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);

        // 🔐 Session check
        if (session == null || session.getAttribute("user_id") == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        int userId = (int) session.getAttribute("user_id");

        ArrayList<String[]> sessions = new ArrayList<>();

        Connection con = null;

        try {

            Class.forName("com.mysql.cj.jdbc.Driver");

            con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/login_project",
                "root",
                ""
            );

            // 🔥 Fetch sessions + rating status
            PreparedStatement ps = con.prepareStatement(
                "SELECT s.id, sk.skill_name, " +
                "CASE WHEN r2.session_id IS NOT NULL THEN 'rated' ELSE 'not_rated' END AS status " +
                "FROM sessions s " +
                "JOIN skill_requests r ON s.request_id = r.id " +
                "JOIN skills sk ON r.skill_id = sk.id " +
                "LEFT JOIN ratings r2 ON s.id = r2.session_id " +
                "WHERE s.status = 'completed' AND r.requester_id = ?"
            );

            ps.setInt(1, userId);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                String[] row = new String[3];

                row[0] = String.valueOf(rs.getInt("id"));   // session_id
                row[1] = rs.getString("skill_name");        // skill name
                row[2] = rs.getString("status");            // rated / not_rated

                sessions.add(row);
            }

            request.setAttribute("sessions", sessions);

            request.getRequestDispatcher("ratesessions.jsp")
                   .forward(request, response);

        } catch(Exception e){
            e.printStackTrace();
            response.getWriter().println("Error: " + e.getMessage());
        } finally {
            try { if (con != null) con.close(); } catch(Exception e){}
        }
    }
}