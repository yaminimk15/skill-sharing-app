import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class NotificationUtil {

    // 🔔 ONLY METHOD (USE THIS EVERYWHERE)
    public static void addNotification(Connection con, int userId, String message, String link) throws SQLException {

        // ❗ Force correct link (NO fallback to dashboard)
        if (link == null || link.trim().isEmpty()) {
            throw new IllegalArgumentException("Notification link cannot be null or empty");
        }

        PreparedStatement ps = con.prepareStatement(
            "INSERT INTO notifications(user_id, message, link) VALUES (?, ?, ?)"
        );

        ps.setInt(1, userId);
        ps.setString(2, message);
        ps.setString(3, link);

        ps.executeUpdate();
        ps.close();
    }
}