import java.io.IOException;
import java.sql.*;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/savesession")
public class SaveSessionServlet extends HttpServlet {

protected void doPost(HttpServletRequest request,
HttpServletResponse response)
throws ServletException, IOException {

Connection con = null;

try{

// 🔥 FIXED PARAMETER NAME
String requestParam = request.getParameter("requestId");

// 🔥 VALIDATION (VERY IMPORTANT)
if(requestParam == null || requestParam.trim().isEmpty()){
    response.getWriter().println("❌ Request ID is missing");
    return;
}

int requestId = Integer.parseInt(requestParam);

// 🔹 Get other data
String date = request.getParameter("date");
String time = request.getParameter("time");

// 🔹 Load driver
Class.forName("com.mysql.cj.jdbc.Driver");

// 🔹 DB connection
con = DriverManager.getConnection(
"jdbc:mysql://localhost:3306/login_project",
"root",
""
);

// 🔥 Insert session
PreparedStatement ps = con.prepareStatement(
"INSERT INTO sessions(request_id, session_date, session_time, status) VALUES(?,?,?,?)"
);

ps.setInt(1, requestId);
ps.setString(2, date);
ps.setString(3, time);
ps.setString(4, "scheduled");

ps.executeUpdate();

// 🔥 Update request status
PreparedStatement ps2 = con.prepareStatement(
"UPDATE skill_requests SET status='accepted' WHERE id=?"
);

ps2.setInt(1, requestId);
ps2.executeUpdate();

// 🔹 Redirect
response.sendRedirect("viewrequests");

} catch(NumberFormatException e){
response.getWriter().println("❌ Invalid Request ID format");
}
catch(Exception e){
e.printStackTrace();
response.getWriter().println("❌ Error: " + e.getMessage());
}
finally {
try {
    if(con != null) con.close();
} catch(Exception e){}
}

}
}