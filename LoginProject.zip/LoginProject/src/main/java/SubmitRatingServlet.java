import java.io.IOException;
import java.sql.*;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/submitrating")
public class SubmitRatingServlet extends HttpServlet {

protected void doPost(HttpServletRequest request,
HttpServletResponse response)
throws ServletException, IOException {

try {

int sessionId = Integer.parseInt(request.getParameter("session_id"));
int teaching = Integer.parseInt(request.getParameter("teaching"));
int communication = Integer.parseInt(request.getParameter("communication"));
int helpfulness = Integer.parseInt(request.getParameter("helpfulness"));
String comment = request.getParameter("comment");

double avg = (teaching + communication + helpfulness) / 3.0;

Class.forName("com.mysql.cj.jdbc.Driver");

Connection con = DriverManager.getConnection(
"jdbc:mysql://localhost:3306/login_project",
"root",
"");

PreparedStatement ps = con.prepareStatement(
"INSERT INTO ratings(session_id, teaching, communication, helpfulness, avg_rating, comment) VALUES(?,?,?,?,?,?)");

ps.setInt(1, sessionId);
ps.setInt(2, teaching);
ps.setInt(3, communication);
ps.setInt(4, helpfulness);
ps.setDouble(5, avg);
ps.setString(6, comment);

ps.executeUpdate();

response.sendRedirect("ratesessions");

} catch(Exception e){
e.printStackTrace();
}
}
}