import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/notifications")
public class NotificationServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request,
                         HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);

        if (session == null || session.getAttribute("user_id") == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        int userId = (int) session.getAttribute("user_id");

        ArrayList<String[]> notifications = new ArrayList<>();

        try {

            Class.forName("com.mysql.cj.jdbc.Driver");

            Connection con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/login_project",
                "root",
                ""
            );

            PreparedStatement ps = con.prepareStatement(
                "SELECT message, link FROM notifications WHERE user_id=? ORDER BY id DESC"
            );

            ps.setInt(1, userId);

            ResultSet rs = ps.executeQuery();

            while(rs.next()){
                String[] n = new String[2];
                n[0] = rs.getString("message");
                n[1] = rs.getString("link");
                notifications.add(n);
            }

            // 🔥 Mark as read
            PreparedStatement ps2 = con.prepareStatement(
                "UPDATE notifications SET status='read' WHERE user_id=?"
            );
            ps2.setInt(1, userId);
            ps2.executeUpdate();

            request.setAttribute("notifications", notifications);

            request.getRequestDispatcher("notifications.jsp")
                   .forward(request, response);

        } catch(Exception e){
            e.printStackTrace();
            response.getWriter().println("Error: " + e.getMessage());
        }
    }
}