import java.io.IOException;
import java.sql.*;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/schedulesession")
public class ScheduleSessionServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request,
                          HttpServletResponse response)
            throws ServletException, IOException {

        // 🔐 Session check
        HttpSession session = request.getSession(false);

        if (session == null || session.getAttribute("user_id") == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        String requestIdParam = request.getParameter("request_id");
        String date = request.getParameter("date");
        String time = request.getParameter("time");

        if (requestIdParam == null || date == null || time == null) {
            response.getWriter().println("Invalid input");
            return;
        }

        Connection con = null;
        PreparedStatement ps = null;

        try {

            Class.forName("com.mysql.cj.jdbc.Driver");

            con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/login_project",
                "root",
                ""
            );

            int requestId = Integer.parseInt(requestIdParam);

            // 🔹 Insert session
            ps = con.prepareStatement(
                "INSERT INTO sessions(request_id, session_date, session_time, status) VALUES(?,?,?,?)"
            );

            ps.setInt(1, requestId);
            ps.setString(2, date);
            ps.setString(3, time);
            ps.setString(4, "Scheduled");

            ps.executeUpdate();

            // 🔹 Get requester and teacher
            PreparedStatement ps1 = con.prepareStatement(
                "SELECT requester_id, teacher_id FROM skill_requests WHERE id=?"
            );

            ps1.setInt(1, requestId);

            ResultSet rs1 = ps1.executeQuery();

            if (rs1.next()) {

                int requesterId = rs1.getInt("requester_id");
                int teacherId = rs1.getInt("teacher_id");

                // 🔔 Notify requester
                NotificationUtil.addNotification(con, requesterId,
                    "📅 Your session has been scheduled",
                    "viewsessions");

                // 🔔 Notify teacher
                NotificationUtil.addNotification(con, teacherId,
                    "📅 Session scheduled successfully",
                    "viewsessions");
            }

            // ✅ Redirect
            response.sendRedirect("viewrequests");

        } catch(Exception e){
            e.printStackTrace();
            response.getWriter().println("Error: " + e.getMessage());
        } finally {
            try { if (ps != null) ps.close(); } catch(Exception e){}
            try { if (con != null) con.close(); } catch(Exception e){}
        }
    }
}