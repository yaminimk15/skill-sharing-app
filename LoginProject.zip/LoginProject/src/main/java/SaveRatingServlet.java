import java.io.IOException;
import java.sql.*;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/saverating")
public class SaveRatingServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request,
                          HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);

        // 🔐 Session check
        if (session == null || session.getAttribute("user_id") == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        String sessionIdParam = request.getParameter("session_id");
        String ratingParam = request.getParameter("rating");
        String feedback = request.getParameter("feedback");

        if (sessionIdParam == null || ratingParam == null) {
            response.getWriter().println("Invalid input");
            return;
        }

        Connection con = null;
        PreparedStatement ps = null;

        try {

            Class.forName("com.mysql.cj.jdbc.Driver");

            con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/login_project",
                "root",
                ""
            );

            int sessionId = Integer.parseInt(sessionIdParam);
            int rating = Integer.parseInt(ratingParam);

            // 🔹 Insert rating
            ps = con.prepareStatement(
                "INSERT INTO ratings(session_id, rating, feedback) VALUES(?,?,?)"
            );

            ps.setInt(1, sessionId);
            ps.setInt(2, rating);
            ps.setString(3, feedback);

            ps.executeUpdate();

            // 🔹 Get teacher_id using JOIN
            PreparedStatement ps1 = con.prepareStatement(
                "SELECT r.teacher_id FROM skill_requests r " +
                "JOIN sessions s ON r.id = s.request_id WHERE s.id=?"
            );

            ps1.setInt(1, sessionId);

            ResultSet rs1 = ps1.executeQuery();

            if (rs1.next()) {
                int teacherId = rs1.getInt("teacher_id");

                // 🔔 ADD NOTIFICATION
                NotificationUtil.addNotification(con, teacherId,
                    "⭐ You received a new rating",
                    "ratesessions");
            }

            // ✅ Redirect
            response.sendRedirect("ratesessions");

        } catch(Exception e){
            e.printStackTrace();
            response.getWriter().println("Error: " + e.getMessage());
        } finally {
            try { if (ps != null) ps.close(); } catch(Exception e){}
            try { if (con != null) con.close(); } catch(Exception e){}
        }
    }
}