import java.io.IOException;
import java.sql.*;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/rejectrequest")
public class RejectRequestServlet extends HttpServlet {

protected void doGet(HttpServletRequest request,
HttpServletResponse response)
throws ServletException, IOException {

String id = request.getParameter("id");

try{

Class.forName("com.mysql.cj.jdbc.Driver");

Connection con = DriverManager.getConnection(
"jdbc:mysql://localhost:3306/login_project",
"root",
"");

PreparedStatement ps = con.prepareStatement(
"UPDATE skill_requests SET status='rejected' WHERE id=?");

ps.setInt(1, Integer.parseInt(id));

ps.executeUpdate();

response.sendRedirect("viewrequests");

}catch(Exception e){

e.printStackTrace();

}

}
}