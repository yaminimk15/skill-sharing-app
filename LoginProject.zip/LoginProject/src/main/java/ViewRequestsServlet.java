import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/viewrequests")
public class ViewRequestsServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request,
                         HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);

        if (session == null || session.getAttribute("user_id") == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        int teacherId = (int) session.getAttribute("user_id");

        ArrayList<String[]> requestList = new ArrayList<>();

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");

            Connection con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/login_project","root","");

            PreparedStatement ps = con.prepareStatement(
                "SELECT r.id, r.skill_id, r.status, u.username " +
                "FROM skill_requests r " +
                "JOIN users u ON r.requester_id = u.id " +
                "WHERE r.teacher_id = ? AND r.requester_id != ?"
            );

            ps.setInt(1, teacherId);
            ps.setInt(2, teacherId);

            ResultSet rs = ps.executeQuery();

            while(rs.next()){
                String[] r = new String[4];

                r[0] = rs.getString("skill_id");
                r[1] = rs.getString("username");
                r[2] = rs.getString("status");
                r[3] = rs.getString("id");

                requestList.add(r);
            }

            request.setAttribute("requests", requestList);

            request.getRequestDispatcher("viewrequests.jsp")
                   .forward(request, response);

        } catch(Exception e){
            e.printStackTrace();
            response.getWriter().println("Error: " + e.getMessage());
        }
    }
}