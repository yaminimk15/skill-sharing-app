import java.io.IOException;
import java.sql.*;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/requestskill")
public class RequestSkillServlet extends HttpServlet {

protected void doGet(HttpServletRequest request,
HttpServletResponse response)
throws ServletException, IOException {

String skillId = request.getParameter("id");

try{

Class.forName("com.mysql.cj.jdbc.Driver");

Connection con = DriverManager.getConnection(
"jdbc:mysql://localhost:3306/login_project",
"root",
"");

PreparedStatement ps = con.prepareStatement(
"INSERT INTO skill_requests(skill_id, requester_id, teacher_id, status) VALUES(?,?,?,?)");

ps.setInt(1, Integer.parseInt(skillId));

ps.setInt(2, 1); // requester id
ps.setInt(3, 1); // teacher id (temporary)
ps.setString(4, "pending");


ps.executeUpdate();

response.sendRedirect("browseskills");

}catch(Exception e){

e.printStackTrace();

}

}
}