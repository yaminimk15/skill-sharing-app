import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/browseskills")
public class BrowseSkillsServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request,
                         HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);

        // 🔐 Check login
        if (session == null || session.getAttribute("user_id") == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        int currentUserId = (int) session.getAttribute("user_id");

        ArrayList<String[]> skills = new ArrayList<>();

        try {

            Class.forName("com.mysql.cj.jdbc.Driver");

            Connection con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/login_project",
                "root",
                ""
            );

            // 🔹 Get all skills except current user's skills
            PreparedStatement ps = con.prepareStatement(
                "SELECT id, skill_name, category FROM skills WHERE user_id != ?"
            );

            ps.setInt(1, currentUserId);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                String[] skill = new String[3];

                // ✅ IMPORTANT ORDER
                skill[0] = String.valueOf(rs.getInt("id")); // ID
                skill[1] = rs.getString("skill_name");      // Name
                skill[2] = rs.getString("category");        // Category

                skills.add(skill);
            }

            request.setAttribute("skills", skills);

            request.getRequestDispatcher("browseskills.jsp")
                   .forward(request, response);

        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().println("Error: " + e.getMessage());
        }
    }
}