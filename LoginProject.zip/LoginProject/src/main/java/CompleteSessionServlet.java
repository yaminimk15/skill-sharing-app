import java.io.IOException;
import java.sql.*;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/completesession")
public class CompleteSessionServlet extends HttpServlet {

protected void doGet(HttpServletRequest request,
HttpServletResponse response)
throws ServletException, IOException {

try{

String idParam = request.getParameter("id");

if(idParam == null || idParam.trim().isEmpty()){
    response.getWriter().println("Session ID missing");
    return;
}

int sessionId = Integer.parseInt(idParam);

// DB connection
Class.forName("com.mysql.cj.jdbc.Driver");

Connection con = DriverManager.getConnection(
"jdbc:mysql://localhost:3306/login_project",
"root",
""
);

// Update status
PreparedStatement ps = con.prepareStatement(
"UPDATE sessions SET status='completed' WHERE id=?"
);

ps.setInt(1, sessionId);
ps.executeUpdate();

con.close();

// Redirect back
response.sendRedirect("viewsessions");

}catch(Exception e){
e.printStackTrace();
response.getWriter().println("Error: " + e.getMessage());
}
}
}