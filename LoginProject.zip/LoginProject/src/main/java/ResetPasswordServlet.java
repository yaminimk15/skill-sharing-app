import java.io.IOException;
import java.sql.*;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import org.mindrot.jbcrypt.BCrypt;

@WebServlet("/resetpassword")
public class ResetPasswordServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request,
                         HttpServletResponse response)
            throws IOException {

        String token = request.getParameter("token");
        String password = request.getParameter("password");

        // 🔐 Validation
        if (token == null || password == null || password.isEmpty()) {
            response.getWriter().println("Invalid request");
            return;
        }

        try {

            Class.forName("com.mysql.cj.jdbc.Driver");

            Connection con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/login_project","root",""
            );

            // 🔐 Hash password
            String hash = BCrypt.hashpw(password, BCrypt.gensalt());

            PreparedStatement ps = con.prepareStatement(
                "UPDATE users SET password=?, reset_token=NULL WHERE reset_token=?"
            );

            ps.setString(1, hash);
            ps.setString(2, token);

            int rows = ps.executeUpdate();

            if (rows > 0) {
                response.getWriter().println("Password updated successfully!");
            } else {
                response.getWriter().println("Invalid or expired token");
            }

        } catch(Exception e){
            e.printStackTrace();
            response.getWriter().println("Error: " + e.getMessage());
        }
    }
}