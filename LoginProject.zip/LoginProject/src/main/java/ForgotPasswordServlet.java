import java.io.IOException;
import java.sql.*;
import java.util.UUID;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/forgotpassword")
public class ForgotPasswordServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request,
                         HttpServletResponse response)
            throws IOException {

        String username = request.getParameter("username");

        try {
            Connection con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/login_project","root","");

            String token = UUID.randomUUID().toString();

            PreparedStatement ps = con.prepareStatement(
                "UPDATE users SET reset_token=? WHERE username=?"
            );

            ps.setString(1, token);
            ps.setString(2, username);
            ps.executeUpdate();

            response.getWriter().println(
                "Use this link: resetpassword.jsp?token=" + token
            );

        } catch(Exception e){
            e.printStackTrace();
        }
    }
}