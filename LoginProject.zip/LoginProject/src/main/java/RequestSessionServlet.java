import java.io.IOException;
import java.sql.*;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/requestsession")
public class RequestSessionServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request,
                          HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);

        // 🔐 Check login
        if (session == null || session.getAttribute("user_id") == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        int requesterId = (int) session.getAttribute("user_id");

        String skillParam = request.getParameter("skill_id");

        if (skillParam == null) {
            response.sendRedirect("browseskills?msg=error");
            return;
        }

        int skillId = Integer.parseInt(skillParam);

        Connection con = null;
        PreparedStatement ps = null;

        try {

            Class.forName("com.mysql.cj.jdbc.Driver");

            con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/login_project",
                "root",
                ""
            );

            // 🔹 Get teacher (skill owner)
            PreparedStatement ps1 = con.prepareStatement(
                "SELECT user_id FROM skills WHERE id=?"
            );

            ps1.setInt(1, skillId);

            ResultSet rs1 = ps1.executeQuery();

            if (!rs1.next()) {
                response.sendRedirect("browseskills?msg=error");
                return;
            }

            int teacherId = rs1.getInt("user_id");

            // ❌ Prevent self-request
            if (teacherId == requesterId) {
                response.sendRedirect("browseskills?msg=self");
                return;
            }

            // 🔹 Insert request
            ps = con.prepareStatement(
                "INSERT INTO skill_requests(skill_id, requester_id, teacher_id, status) VALUES(?,?,?,?)"
            );

            ps.setInt(1, skillId);
            ps.setInt(2, requesterId);
            ps.setInt(3, teacherId);
            ps.setString(4, "pending");

            ps.executeUpdate();

            // 🔔 Notification
            NotificationUtil.addNotification(con, teacherId,
                "📩 New request received for your skill",
                "viewrequests");

            // ✅ Success redirect
            response.sendRedirect("browseskills?msg=success");

        } catch(Exception e){
            e.printStackTrace();
            response.sendRedirect("browseskills?msg=error");
        } finally {
            try { if (ps != null) ps.close(); } catch(Exception e){}
            try { if (con != null) con.close(); } catch(Exception e){}
        }
    }
}