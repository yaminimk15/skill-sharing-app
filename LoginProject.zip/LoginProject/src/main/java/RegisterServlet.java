import java.io.IOException;
import java.sql.*;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import org.mindrot.jbcrypt.BCrypt;

@WebServlet("/register")
public class RegisterServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request,
                          HttpServletResponse response)
            throws ServletException, IOException {

        String username = request.getParameter("username");
        String password = request.getParameter("password");

        // 🔐 Basic validation
        if (username == null || password == null ||
            username.isEmpty() || password.isEmpty()) {

            response.getWriter().println("All fields are required");
            return;
        }

        Connection con = null;
        PreparedStatement ps = null;

        try {

            Class.forName("com.mysql.cj.jdbc.Driver");

            con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/login_project",
                "root",
                ""
            );

            // 🔍 Check if user exists
            PreparedStatement check = con.prepareStatement(
                "SELECT id FROM users WHERE username=?"
            );
            check.setString(1, username);

            ResultSet rs = check.executeQuery();

            if (rs.next()) {
                response.getWriter().println("Username already exists");
                return;
            }

            // 🔐 Hash password
            String hashedPassword = BCrypt.hashpw(password, BCrypt.gensalt());

            // ✅ Insert user
            ps = con.prepareStatement(
                "INSERT INTO users(username, password) VALUES(?,?)"
            );

            ps.setString(1, username);
            ps.setString(2, hashedPassword);

            ps.executeUpdate();

            // ✅ Redirect to login
            response.sendRedirect("login.jsp?msg=registered");

        } catch(Exception e){
            e.printStackTrace();
            response.getWriter().println("Error: " + e.getMessage());
        } finally {
            try { if (ps != null) ps.close(); } catch(Exception e){}
            try { if (con != null) con.close(); } catch(Exception e){}
        }
    }
}