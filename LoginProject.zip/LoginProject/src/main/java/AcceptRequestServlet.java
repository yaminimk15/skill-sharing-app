import java.io.IOException;
import java.sql.*;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/acceptrequest")
public class AcceptRequestServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request,
                         HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);

        // 🔐 Check login
        if (session == null || session.getAttribute("user_id") == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        String id = request.getParameter("id");

        if (id == null) {
            response.getWriter().println("Invalid request ID");
            return;
        }

        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {

            Class.forName("com.mysql.cj.jdbc.Driver");

            con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/login_project",
                "root",
                ""
            );

            int requestId = Integer.parseInt(id);

            // 🔹 Get requester_id BEFORE updating
            PreparedStatement ps1 = con.prepareStatement(
                "SELECT requester_id FROM skill_requests WHERE id=?"
            );

            ps1.setInt(1, requestId);

            ResultSet rs1 = ps1.executeQuery();

            if (!rs1.next()) {
                response.getWriter().println("Request not found");
                return;
            }

            int requesterId = rs1.getInt("requester_id");

            // 🔹 Update status
            ps = con.prepareStatement(
                "UPDATE skill_requests SET status='accepted' WHERE id=?"
            );

            ps.setInt(1, requestId);
            ps.executeUpdate();

            // 🔔 ADD NOTIFICATION (FINAL)
            NotificationUtil.addNotification(con, requesterId,
                "✅ Your request has been accepted",
                "viewsessions");

            // ✅ Redirect
            response.sendRedirect("viewrequests");

        } catch(Exception e){
            e.printStackTrace();
            response.getWriter().println("Error: " + e.getMessage());
        } finally {

            try { if (rs != null) rs.close(); } catch(Exception e){}
            try { if (ps != null) ps.close(); } catch(Exception e){}
            try { if (con != null) con.close(); } catch(Exception e){}
        }
    }
}