import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/viewsessions")
public class ViewSessionsServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request,
                         HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);

        if (session == null || session.getAttribute("user_id") == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        int userId = (int) session.getAttribute("user_id");

        ArrayList<String[]> sessionList = new ArrayList<>();

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");

            Connection con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/login_project","root","");

            PreparedStatement ps = con.prepareStatement(
                "SELECT s.id, sk.skill_name, u.username, s.session_date, s.session_time, s.status " +
                "FROM sessions s " +
                "JOIN skill_requests r ON s.request_id = r.id " +
                "JOIN skills sk ON r.skill_id = sk.id " +
                "JOIN users u ON r.requester_id = u.id " +
                "WHERE r.teacher_id = ?"
            );

            ps.setInt(1, userId);

            ResultSet rs = ps.executeQuery();

            while(rs.next()){
                String[] s = new String[6];

                s[0] = rs.getString("id");
                s[1] = rs.getString("skill_name");
                s[2] = rs.getString("username");
                s[3] = rs.getString("session_date");
                s[4] = rs.getString("session_time");
                s[5] = rs.getString("status");

                sessionList.add(s);
            }

            request.setAttribute("sessions", sessionList);

            // ✅ THIS LINE IS THE MOST IMPORTANT
            request.getRequestDispatcher("viewsessions.jsp")
                   .forward(request, response);

        } catch(Exception e){
            e.printStackTrace();
        }
    }
}