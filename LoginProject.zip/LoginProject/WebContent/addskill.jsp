<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Add Skill</title>

<!-- ✅ Bootstrap -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

<!-- ✅ Font Awesome -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<!-- ✅ Google Font -->
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;500;700&display=swap" rel="stylesheet">

<style>
body {
    font-family: 'Poppins', sans-serif;
    background: linear-gradient(-45deg, #667eea, #764ba2, #43cea2, #185a9d);
    background-size: 400% 400%;
    animation: gradientMove 10s ease infinite;
    min-height: 100vh;
}

/* Animation */
@keyframes gradientMove {
    0% { background-position: 0% 50%; }
    50% { background-position: 100% 50%; }
    100% { background-position: 0% 50%; }
}

/* Glass Card */
.glass-card {
    background: rgba(255,255,255,0.15);
    backdrop-filter: blur(12px);
    border-radius: 20px;
    padding: 30px;
    color: white;
    box-shadow: 0 0 25px rgba(255,255,255,0.2);
}

/* Input styling */
.form-control, .form-select {
    border-radius: 10px;
}

/* Button hover */
.btn:hover {
    transform: scale(1.05);
}
</style>

</head>

<body>

<div class="container d-flex justify-content-center align-items-center" style="min-height:100vh;">

    <div class="glass-card shadow-lg" style="width: 400px;">

        <h3 class="text-center mb-4">
            <i class="fas fa-plus-circle"></i> Add New Skill
        </h3>

        <form action="addskill" method="post">

            <!-- Skill Name -->
            <div class="mb-3">
                <label class="form-label">Skill Name</label>
                <input type="text" name="skill" class="form-control" placeholder="Enter skill">
            </div>

            <!-- Category -->
            <div class="mb-3">
                <label class="form-label">Category</label>
                <input type="text" name="category" class="form-control" placeholder="Enter category">
            </div>

            <!-- Type -->
            <div class="mb-3">
                <label class="form-label">Type</label>
                <select name="type" class="form-select">
                    <option value="teach">Teach</option>
                    <option value="learn">Learn</option>
                </select>
            </div>

            <!-- Buttons -->
            <div class="d-grid gap-2 mt-4">

                <button type="submit" class="btn btn-success">
                    <i class="fas fa-check"></i> Add Skill
                </button>

                <a href="dashboard" class="btn btn-light text-dark">
                    <i class="fas fa-arrow-left"></i> Back
                </a>

            </div>

        </form>

    </div>

</div>

</body>
</html>