<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Register</title>

<!-- Bootstrap -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

<!-- Font Awesome -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<style>
body {
    background: linear-gradient(-45deg, #667eea, #764ba2, #43cea2, #185a9d);
    background-size: 400% 400%;
    animation: gradientMove 10s ease infinite;
    min-height: 100vh;
    display: flex;
    justify-content: center;
    align-items: center;
}

@keyframes gradientMove {
    0% {background-position: 0% 50%;}
    50% {background-position: 100% 50%;}
    100% {background-position: 0% 50%;}
}

.card {
    background: rgba(255,255,255,0.15);
    backdrop-filter: blur(10px);
    border-radius: 15px;
    color: white;
    width: 400px;
}

.form-control {
    border-radius: 10px;
}

.btn {
    border-radius: 10px;
}
</style>

</head>

<body>

<div class="card p-4 shadow-lg">

<h3 class="text-center mb-4">
    <i class="fas fa-user-plus"></i> Create Account
</h3>

<form action="register" method="post">

<div class="mb-3">
<label>Username</label>
<input type="text" name="username" class="form-control" required>
</div>

<div class="mb-3">
<label>Email</label>
<input type="email" name="email" class="form-control" required>
</div>

<div class="mb-3">
<label>Password</label>
<input type="password" name="password" class="form-control" required>
</div>

<div class="mb-3">
<label>Confirm Password</label>
<input type="password" name="confirm_password" class="form-control" required>
</div>

<div class="d-grid gap-2 mt-3">

<button type="submit" class="btn btn-success">
<i class="fas fa-user-check"></i> Register
</button>

<a href="login.jsp" class="btn btn-light">
<i class="fas fa-arrow-left"></i> Back to Login
</a>

</div>

</form>

</div>

</body>
</html>