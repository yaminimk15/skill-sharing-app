<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Login</title>

<!-- ✅ Bootstrap -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

<!-- ✅ Font Awesome -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<!-- ✅ Google Font -->
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;500;700&display=swap" rel="stylesheet">

<style>
body {
    font-family: 'Poppins', sans-serif;
    background: linear-gradient(-45deg, #667eea, #764ba2, #43cea2, #185a9d);
    background-size: 400% 400%;
    animation: gradientMove 10s ease infinite;
    min-height: 100vh;
}

/* Animation */
@keyframes gradientMove {
    0% { background-position: 0% 50%; }
    50% { background-position: 100% 50%; }
    100% { background-position: 0% 50%; }
}

/* Glass Card */
.glass-card {
    background: rgba(255,255,255,0.15);
    backdrop-filter: blur(12px);
    border-radius: 20px;
    padding: 30px;
    color: white;
    box-shadow: 0 0 25px rgba(255,255,255,0.2);
}

/* Input styling */
.form-control {
    border-radius: 10px;
}

/* Button hover */
.btn:hover {
    transform: scale(1.05);
}

/* Links */
a {
    color: #fff;
    text-decoration: none;
}
a:hover {
    text-decoration: underline;
}
</style>

</head>

<body>

<div class="container d-flex justify-content-center align-items-center" style="min-height:100vh;">

    <div class="glass-card shadow-lg" style="width: 380px;">

        <h3 class="text-center mb-4">
            <i class="fas fa-user-circle"></i> Login
        </h3>

        <form action="login" method="post">

            <!-- Username -->
            <div class="mb-3">
                <label class="form-label">Username</label>
                <div class="input-group">
                    <span class="input-group-text"><i class="fas fa-user"></i></span>
                    <input type="text" name="username" class="form-control" placeholder="Enter username" required>
                </div>
            </div>

            <!-- Password -->
            <div class="mb-3">
                <label class="form-label">Password</label>
                <div class="input-group">
                    <span class="input-group-text"><i class="fas fa-lock"></i></span>
                    <input type="password" name="password" class="form-control" placeholder="Enter password" required>
                </div>
            </div>

            <!-- Login Button -->
            <div class="d-grid mt-4">
                <button type="submit" class="btn btn-success">
                    <i class="fas fa-sign-in-alt"></i> Login
                </button>
            </div>

        </form>

        <!-- Register Link -->
        <p class="text-center mt-3">
            Don't have an account?
            <a href="register.jsp"><b>Register</b></a>
        </p>

    </div>

</div>

</body>
</html>