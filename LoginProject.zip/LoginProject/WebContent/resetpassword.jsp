<form action="resetpassword" method="post">

<input type="hidden" name="token" value="<%= request.getParameter("token") %>">

New Password:
<input type="password" name="password" required>

<button type="submit">Update</button>

</form>