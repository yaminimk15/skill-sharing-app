<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ page import="java.util.*" %>

<%
String msg = request.getParameter("msg");
ArrayList<String[]> skills = (ArrayList<String[]>) request.getAttribute("skills");
%>

<!DOCTYPE html>
<html>
<head>
<title>Browse Skills</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<style>
body {
    background: linear-gradient(-45deg, #667eea, #764ba2, #43cea2, #185a9d);
    background-size: 400% 400%;
    animation: gradientMove 10s ease infinite;
}

@keyframes gradientMove {
    0% {background-position: 0% 50%;}
    50% {background-position: 100% 50%;}
    100% {background-position: 0% 50%;}
}

.container-box {
    max-width: 900px;
    margin: 50px auto;
}

.card {
    background: rgba(255,255,255,0.15);
    backdrop-filter: blur(10px);
    border-radius: 15px;
    color: white;
}
</style>

</head>

<body>

<div class="container-box">

<div class="card p-4 shadow-lg">

<h3 class="text-center mb-4">
    <i class="fas fa-search text-info"></i> Browse Skills
</h3>

<!-- ✅ MESSAGE -->
<%
if ("success".equals(msg)) {
%>
<div class="alert alert-success text-center">
    <i class="fas fa-check-circle"></i> Request sent successfully!
</div>
<%
} else if ("error".equals(msg)) {
%>
<div class="alert alert-danger text-center">
    ❌ Something went wrong!
</div>
<%
} else if ("self".equals(msg)) {
%>
<div class="alert alert-warning text-center">
    ⚠️ You cannot request your own skill!
</div>
<%
}
%>

<table class="table table-dark table-hover text-center">

<tr>
<th>Skill</th>
<th>Category</th>
<th>Action</th>
</tr>

<%
if (skills != null && !skills.isEmpty()) {
    for (String[] s : skills) {
%>

<tr>
<td><%= s[1] %></td>
<td><%= s[2] %></td>

<td>
<form action="requestsession" method="post">

<!-- ✅ CORRECT ID -->
<input type="hidden" name="skill_id" value="<%= s[0] %>">

<button class="btn btn-success">
    <i class="fas fa-paper-plane"></i> Request
</button>

</form>
</td>

</tr>

<%
    }
} else {
%>

<tr>
<td colspan="3">No skills available</td>
</tr>

<%
}
%>

</table>

<div class="text-center mt-3">
<a href="dashboard" class="btn btn-light">
<i class="fas fa-arrow-left"></i> Back
</a>
</div>

</div>

</div>

</body>
</html>