<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ page import="java.util.*" %>

<%
response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");

if (session == null || session.getAttribute("user_id") == null) {
    response.sendRedirect("login.jsp");
    return;
}

ArrayList<String[]> sessions = (ArrayList<String[]>) request.getAttribute("sessions");
%>

<!DOCTYPE html>
<html>
<head>
<title>Rate Sessions</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<style>
body {
    background: linear-gradient(-45deg, #667eea, #764ba2, #43cea2, #185a9d);
    background-size: 400% 400%;
    animation: gradientMove 10s ease infinite;
}

@keyframes gradientMove {
    0% {background-position: 0% 50%;}
    50% {background-position: 100% 50%;}
    100% {background-position: 0% 50%;}
}

.container-box {
    max-width: 800px;
    margin: 50px auto;
}

.card {
    background: rgba(255,255,255,0.15);
    backdrop-filter: blur(10px);
    border-radius: 15px;
    color: white;
}
</style>

</head>

<body>

<div class="container-box">

<div class="card p-4 shadow-lg">

<h3 class="text-center mb-4">
    ⭐ Rate Your Sessions
</h3>

<table class="table table-dark table-hover text-center">

<tr>
<th>Skill</th>
<th>Action</th>
</tr>

<%
if (sessions != null && !sessions.isEmpty()) {

    for(String[] s : sessions){
%>

<tr>

<td><%= s[1] %></td>

<td>

<%
if("rated".equals(s[2])) {
%>

<button class="btn btn-secondary" disabled>
    ✔ Already Rated
</button>

<%
} else {
%>

<a href="ratesessionform.jsp?session_id=<%= s[0] %>" class="btn btn-success">
    ⭐ Rate Now
</a>

<%
}
%>

</td>

</tr>

<%
    }

} else {
%>

<tr>
<td colspan="2">No sessions available</td>
</tr>

<%
}
%>

</table>

<div class="text-center mt-3">
<a href="dashboard" class="btn btn-light">
    <i class="fas fa-arrow-left"></i> Back
</a>
</div>

</div>

</div>

</body>
</html>