<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ page import="java.util.*" %>

<%
    // 🔐 Prevent cache
    response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");

    if (session == null || session.getAttribute("user_id") == null) {
        response.sendRedirect("login.jsp");
        return;
    }

    ArrayList<String[]> notifications = (ArrayList<String[]>) request.getAttribute("notifications");
%>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Notifications</title>

<!-- Bootstrap -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

<!-- Font Awesome -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<style>
body {
    background: linear-gradient(-45deg, #667eea, #764ba2, #43cea2, #185a9d);
    background-size: 400% 400%;
    animation: gradientMove 10s ease infinite;
    min-height: 100vh;
}

@keyframes gradientMove {
    0% {background-position: 0% 50%;}
    50% {background-position: 100% 50%;}
    100% {background-position: 0% 50%;}
}

.container-box {
    max-width: 600px;
    margin: 60px auto;
}

.card {
    background: rgba(255,255,255,0.15);
    backdrop-filter: blur(10px);
    border-radius: 15px;
    color: white;
}

/* Notification box */
.notification {
    background: rgba(255,255,255,0.1);
    padding: 15px;
    border-radius: 12px;
    margin-bottom: 12px;
    transition: 0.3s;
    display: flex;
    align-items: center;
    gap: 10px;
}

.notification:hover {
    background: rgba(255,255,255,0.25);
    transform: scale(1.02);
}

.notification i {
    font-size: 18px;
}
</style>

</head>

<body>

<div class="container-box">

<div class="card p-4 shadow-lg">

<h3 class="text-center mb-4">
    <i class="fas fa-bell text-warning"></i> Notifications
</h3>

<%
if (notifications != null && !notifications.isEmpty()) {
    for (String[] n : notifications) {
%>

<a href="<%= n[1] %>" style="text-decoration:none; color:white;">

<div class="notification">
    <i class="fas fa-envelope text-info"></i>
    <span><%= n[0] %></span>
</div>

</a>

<%
    }
} else {
%>

<div class="text-center">
    <i class="fas fa-bell-slash fa-2x text-light"></i>
    <p class="mt-2">No notifications yet</p>
</div>

<%
}
%>

<div class="text-center mt-4">
    <a href="dashboard" class="btn btn-light">
        <i class="fas fa-arrow-left"></i> Back to Dashboard
    </a>
</div>

</div>

</div>

</body>
</html>