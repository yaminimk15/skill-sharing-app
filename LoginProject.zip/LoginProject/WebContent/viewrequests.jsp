<%@ page import="java.util.*" %>

<%
response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");

if (session == null || session.getAttribute("user_id") == null) {
    response.sendRedirect("login.jsp");
    return;
}
%>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>View Requests</title>

<!-- Bootstrap -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

<!-- Font Awesome -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<style>
body {
    background: linear-gradient(-45deg, #667eea, #764ba2, #43cea2, #185a9d);
    background-size: 400% 400%;
    animation: gradientMove 10s ease infinite;
    min-height: 100vh;
}

@keyframes gradientMove {
    0% { background-position: 0% 50%; }
    50% { background-position: 100% 50%; }
    100% { background-position: 0% 50%; }
}

.card {
    background: rgba(255,255,255,0.15);
    backdrop-filter: blur(10px);
    border-radius: 15px;
    color: white;
}

.table {
    background: white;
    color: black;
}
</style>

</head>

<body>

<div class="container mt-5">

<div class="card p-4 shadow-lg">

<h3 class="text-center mb-4">
    <i class="fas fa-envelope"></i> Incoming Requests
</h3>

<table class="table table-bordered text-center">

<tr class="table-dark">
<th>Skill ID</th>
<th>Requester</th>
<th>Status</th>
<th>Action</th>
</tr>

<%
ArrayList<String[]> requests = (ArrayList<String[]>) request.getAttribute("requests");

if (requests != null && !requests.isEmpty()) {
    for (String[] r : requests) {
%>

<tr>
<td><%= r[0] %></td>
<td><%= r[1] %></td>
<td><%= r[2] %></td>

<td>

<a href="acceptrequest?id=<%= r[3] %>" class="btn btn-success btn-sm">
<i class="fas fa-check"></i>
</a>

<a href="rejectrequest?id=<%= r[3] %>" class="btn btn-danger btn-sm">
<i class="fas fa-times"></i>
</a>

<a href="schedule.jsp?id=<%= r[3] %>" class="btn btn-warning btn-sm">
<i class="fas fa-calendar"></i>
</a>

</td>
</tr>

<%
    }
} else {
%>

<tr>
<td colspan="4">No requests found</td>
</tr>

<%
}
%>

</table>

<div class="text-center mt-3">
<a href="dashboard" class="btn btn-light">
<i class="fas fa-arrow-left"></i> Back
</a>
</div>

</div>

</div>

</body>
</html>