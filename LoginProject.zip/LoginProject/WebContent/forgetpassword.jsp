<form action="forgotpassword" method="post">
    Enter Username:
    <input type="text" name="username" required>

    <button type="submit">Reset Password</button>
</form>