<%@ page import="java.util.*" %>

<%
response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");

if (session == null || session.getAttribute("user_id") == null) {
    response.sendRedirect("login.jsp");
    return;
}
%>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>My Sessions</title>

<!-- Bootstrap -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

<!-- Font Awesome -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<style>
body {
    background: linear-gradient(-45deg, #667eea, #764ba2, #43cea2, #185a9d);
    background-size: 400% 400%;
    animation: gradientMove 10s ease infinite;
    min-height: 100vh;
}

/* Animation */
@keyframes gradientMove {
    0% { background-position: 0% 50%; }
    50% { background-position: 100% 50%; }
    100% { background-position: 0% 50%; }
}

/* Glass Card */
.card {
    background: rgba(255,255,255,0.15);
    backdrop-filter: blur(10px);
    border-radius: 15px;
    color: white;
}

/* Table */
.table {
    background: white;
    color: black;
}

/* Hover effect */
.btn:hover {
    transform: scale(1.05);
}
</style>

</head>

<body>

<div class="container mt-5">

<div class="card p-4 shadow-lg">

<h3 class="text-center mb-4">
    <i class="fas fa-calendar-check"></i> Scheduled Sessions
</h3>

<table class="table table-bordered text-center">

<tr class="table-dark">
<th>ID</th>
<th>Skill</th>
<th>Student</th>
<th>Date</th>
<th>Time</th>
<th>Status</th>
<th>Action</th>
</tr>

<%
ArrayList<String[]> sessions = (ArrayList<String[]>) request.getAttribute("sessions");

if (sessions != null && !sessions.isEmpty()) {
    for (String[] s : sessions) {
%>

<tr>

<td><%= s[0] %></td>
<td><%= s[1] %></td>
<td><%= s[2] %></td>
<td><%= s[3] %></td>
<td><%= s[4] %></td>

<td>
<%
if("scheduled".equalsIgnoreCase(s[5])){
%>
<span class="badge bg-warning text-dark">Scheduled</span>
<%
} else {
%>
<span class="badge bg-success">Completed</span>
<%
}
%>
</td>

<td>

<%
if("scheduled".equalsIgnoreCase(s[5])){
%>

<a href="completesession?id=<%= s[0] %>" class="btn btn-success btn-sm">
<i class="fas fa-check"></i>
</a>

<%
} else {
%>

<span class="text-muted">Done</span>

<%
}
%>

</td>

</tr>

<%
    }
} else {
%>

<tr>
<td colspan="7">No sessions found</td>
</tr>

<%
}
%>

</table>

<div class="text-center mt-3">

<a href="dashboard" class="btn btn-light">
<i class="fas fa-arrow-left"></i> Back
</a>

</div>

</div>

</div>

</body>
</html>