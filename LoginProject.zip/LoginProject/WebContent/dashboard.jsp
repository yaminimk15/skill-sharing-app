<%@ page contentType="text/html; charset=UTF-8" %>

<%
if (session == null || session.getAttribute("user_id") == null) {
    response.sendRedirect("login.jsp");
    return;
}

String username = (String) session.getAttribute("username");
%>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Dashboard</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<style>

/* 🌈 Background */
body {
    margin: 0;
    font-family: 'Segoe UI', sans-serif;
    background: linear-gradient(-45deg, #667eea, #764ba2, #43cea2, #185a9d);
    background-size: 400% 400%;
    animation: gradientMove 10s ease infinite;
}

@keyframes gradientMove {
    0% {background-position: 0% 50%;}
    50% {background-position: 100% 50%;}
    100% {background-position: 0% 50%;}
}

/* Sidebar */
.sidebar {
    width: 240px;
    height: 100vh;
    position: fixed;
    background: rgba(0,0,0,0.7);
    backdrop-filter: blur(10px);
    padding: 20px;
    color: white;
}

.sidebar h3 {
    margin-bottom: 20px;
}

.sidebar a {
    display: block;
    color: white;
    text-decoration: none;
    padding: 12px;
    border-radius: 10px;
    margin-bottom: 10px;
    transition: 0.3s;
}

.sidebar a:hover {
    background: rgba(255,255,255,0.2);
}

/* Content */
.content {
    margin-left: 260px;
    padding: 30px;
}

/* Hero */
.hero {
    background: rgba(255,255,255,0.1);
    backdrop-filter: blur(10px);
    padding: 30px;
    border-radius: 20px;
    color: white;
}

/* Cards */
.card-box {
    background: rgba(255,255,255,0.15);
    backdrop-filter: blur(10px);
    border-radius: 15px;
    padding: 20px;
    text-align: center;
    color: white;
    transition: 0.3s;
}

.card-box:hover {
    transform: translateY(-5px);
}

/* Icon colors */
.add { color: #00ff88; }
.browse { color: #4dabf7; }
.skills { color: #ffc107; }
.requests { color: #00d4ff; }
.sessions { color: #ff6b6b; }
.ratings { color: gold; }
.notify { color: #adb5bd; }
.logout { color: #ff4d4d; }

.icon {
    margin-right: 10px;
}

</style>

</head>

<body>

<!-- Sidebar -->
<div class="sidebar">

<h3><i class="fas fa-rocket"></i> Skills</h3>

<a href="addskill.jsp"><i class="fas fa-plus icon add"></i> Add Skill</a>
<a href="browseskills"><i class="fas fa-search icon browse"></i> Browse Skills</a>
<a href="myskills"><i class="fas fa-folder icon skills"></i> My Skills</a>
<a href="viewrequests"><i class="fas fa-envelope icon requests"></i> Requests</a>
<a href="viewsessions"><i class="fas fa-calendar icon sessions"></i> Sessions</a>
<a href="ratesessions"><i class="fas fa-star icon ratings"></i> Ratings</a>
<a href="notifications"><i class="fas fa-bell icon notify"></i> Notifications</a>
<a href="logout"><i class="fas fa-sign-out-alt icon logout"></i> Logout</a>

</div>

<!-- Main Content -->
<div class="content">

<!-- Hero Section -->
<div class="hero shadow-lg">
<h2><i class="fas fa-user"></i> Welcome, <%= username %></h2>
<p>Manage your skills and connect with others 🚀</p>
</div>

<!-- Cards -->
<div class="row mt-4">

<div class="col-md-3">
<div class="card-box shadow">
<i class="fas fa-book fa-2x text-primary"></i>
<h5 class="mt-2">My Skills</h5>
</div>
</div>

<div class="col-md-3">
<div class="card-box shadow">
<i class="fas fa-envelope fa-2x text-success"></i>
<h5 class="mt-2">Requests</h5>
</div>
</div>

<div class="col-md-3">
<div class="card-box shadow">
<i class="fas fa-calendar fa-2x text-danger"></i>
<h5 class="mt-2">Sessions</h5>
</div>
</div>

<div class="col-md-3">
<div class="card-box shadow">
<i class="fas fa-star fa-2x text-warning"></i>
<h5 class="mt-2">Ratings</h5>
</div>
</div>

</div>

</div>

</body>
</html>