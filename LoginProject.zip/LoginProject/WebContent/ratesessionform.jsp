<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>

<%
response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");

if (session == null || session.getAttribute("user_id") == null) {
    response.sendRedirect("login.jsp");
    return;
}

String sessionId = request.getParameter("session_id");
%>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Rate Session</title>

<!-- Bootstrap -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

<!-- Font Awesome (IMPORTANT) -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<style>
body {
    background: linear-gradient(-45deg, #667eea, #764ba2, #43cea2, #185a9d);
    background-size: 400% 400%;
    animation: gradientMove 10s ease infinite;
    min-height: 100vh;
}

@keyframes gradientMove {
    0% { background-position: 0% 50%; }
    50% { background-position: 100% 50%; }
    100% { background-position: 0% 50%; }
}

/* Glass Card */
.card {
    background: rgba(255,255,255,0.15);
    backdrop-filter: blur(10px);
    border-radius: 15px;
    color: white;
}

/* Star Styling */
.star {
    font-size: 30px;
    cursor: pointer;
    color: #ccc;
    transition: 0.2s;
}

.star:hover {
    transform: scale(1.2);
}

.star.selected {
    color: gold;
}
</style>

<script>
function selectRating(val) {
    document.getElementById("rating").value = val;

    let stars = document.querySelectorAll(".star");

    stars.forEach((star, index) => {
        if (index < val) {
            star.classList.add("selected");
        } else {
            star.classList.remove("selected");
        }
    });
}
</script>

</head>

<body>

<div class="container d-flex justify-content-center align-items-center" style="min-height:100vh;">

<div class="card p-4 shadow-lg" style="width: 400px;">

<h3 class="text-center mb-4">
    <i class="fas fa-star"></i> Rate Session
</h3>

<form action="saverating" method="post">

<!-- Hidden session ID -->
<input type="hidden" name="session_id" value="<%= sessionId %>">

<!-- ⭐ Rating Stars -->
<div class="mb-3 text-center">

<label class="form-label d-block">Select Rating</label>

<i class="fas fa-star star" onclick="selectRating(1)"></i>
<i class="fas fa-star star" onclick="selectRating(2)"></i>
<i class="fas fa-star star" onclick="selectRating(3)"></i>
<i class="fas fa-star star" onclick="selectRating(4)"></i>
<i class="fas fa-star star" onclick="selectRating(5)"></i>

<input type="hidden" id="rating" name="rating" required>

</div>

<!-- Feedback -->
<div class="mb-3">
<label class="form-label">Feedback</label>
<textarea name="feedback" class="form-control" rows="3" placeholder="Write your experience..."></textarea>
</div>

<!-- Buttons -->
<div class="d-grid gap-2">

<button type="submit" class="btn btn-warning">
<i class="fas fa-paper-plane"></i> Submit Rating
</button>

<a href="ratesessions" class="btn btn-light">
<i class="fas fa-arrow-left"></i> Back
</a>

</div>

</form>

</div>

</div>

</body>
</html>