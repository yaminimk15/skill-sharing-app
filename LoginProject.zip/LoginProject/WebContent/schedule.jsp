<%
response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");

if (session == null || session.getAttribute("user_id") == null) {
    response.sendRedirect("login.jsp");
    return;
}

// get request id from URL
String requestId = request.getParameter("id");
%>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Schedule Session</title>

<!-- Bootstrap -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

<!-- Font Awesome -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<style>
body {
    background: linear-gradient(-45deg, #667eea, #764ba2, #43cea2, #185a9d);
    background-size: 400% 400%;
    animation: gradientMove 10s ease infinite;
    min-height: 100vh;
}

@keyframes gradientMove {
    0% { background-position: 0% 50%; }
    50% { background-position: 100% 50%; }
    100% { background-position: 0% 50%; }
}

/* Glass card */
.card {
    background: rgba(255,255,255,0.15);
    backdrop-filter: blur(10px);
    border-radius: 15px;
    color: white;
}

/* Inputs */
.form-control {
    border-radius: 10px;
}

/* Button hover */
.btn:hover {
    transform: scale(1.05);
}
</style>

</head>

<body>

<div class="container d-flex justify-content-center align-items-center" style="min-height:100vh;">

<div class="card p-4 shadow-lg" style="width: 400px;">

<h3 class="text-center mb-4">
    <i class="fas fa-calendar-plus"></i> Schedule Session
</h3>

<form action="schedulesession" method="post">

    <!-- Hidden request ID -->
    <input type="hidden" name="request_id" value="<%= requestId %>">

    <!-- Date -->
    <div class="mb-3">
        <label class="form-label">Select Date</label>
        <input type="date" name="date" class="form-control" required>
    </div>

    <!-- Time -->
    <div class="mb-3">
        <label class="form-label">Select Time</label>
        <input type="time" name="time" class="form-control" required>
    </div>

    <!-- Buttons -->
    <div class="d-grid gap-2 mt-4">

        <button type="submit" class="btn btn-success">
            <i class="fas fa-check"></i> Confirm Schedule
        </button>

        <a href="viewrequests" class="btn btn-light text-dark">
            <i class="fas fa-arrow-left"></i> Back
        </a>

    </div>

</form>

</div>

</div>

</body>
</html>