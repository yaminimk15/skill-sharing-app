<%@ page import="java.util.*" %>

<%
response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");

if (session == null || session.getAttribute("user_id") == null) {
    response.sendRedirect("login.jsp");
    return;
}
%>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Rate Sessions</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<style>
body {
    background: linear-gradient(-45deg, #667eea, #764ba2, #43cea2, #185a9d);
    background-size: 400% 400%;
    animation: gradientMove 10s ease infinite;
}

@keyframes gradientMove {
    0% { background-position: 0% 50%; }
    50% { background-position: 100% 50%; }
    100% { background-position: 0% 50%; }
}

.card {
    background: rgba(255,255,255,0.15);
    backdrop-filter: blur(10px);
    border-radius: 15px;
    color: white;
}

.table {
    background: white;
    color: black;
}
</style>

</head>

<body>

<div class="container mt-5">

<div class="card p-4 shadow-lg">

<h3 class="text-center mb-4">
    <i class="fas fa-star"></i> Rate Your Sessions
</h3>

<table class="table table-bordered text-center">

<tr class="table-dark">
<th>Session ID</th>
<th>Session</th>
<th>Action</th>
</tr>

<%
ArrayList<String[]> sessions = (ArrayList<String[]>) request.getAttribute("sessions");

if (sessions != null && !sessions.isEmpty()) {
    for (String[] s : sessions) {
%>

<tr>
<td><%= s[0] %></td>
<td><%= s[1] %> Session</td>

<td>
<a href="ratesessionform.jsp?session_id=<%= s[0] %>" class="btn btn-warning btn-sm">
<i class="fas fa-star"></i> Rate Now
</a>
</td>
</tr>

<%
    }
} else {
%>

<tr>
<td colspan="3">No completed sessions to rate</td>
</tr>

<%
}
%>

</table>

<div class="text-center mt-3">
<a href="dashboard" class="btn btn-light">
<i class="fas fa-arrow-left"></i> Back
</a>
</div>

</div>

</div>

</body>
</html>